// Dog.java (Subclass)
public class Dog extends Animal {
    private String breed;

    public Dog(String species, int age, double weight, String breed) {
        super(species, age, weight);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "species='" + getSpecies() + '\'' +
                ", age=" + getAge() +
                ", weight=" + getWeight() +
                ", breed='" + breed + '\'' +
                '}';
    }
}
