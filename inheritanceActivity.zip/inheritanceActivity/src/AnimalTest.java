// AnimalTest.java (Test class for superclass)
import org.junit.Test;
import static org.junit.Assert.*;

public class AnimalTest {
    @Test
    public void testToString() {
        Animal animal = new Animal("Lion", 5, 150.5);
        String expected = "Animal{species='Lion', age=5, weight=150.5}";
        assertEquals(expected, animal.toString());
    }

    @Test
    public void testGetSpecies() {
        Animal animal = new Animal("Lion", 5, 150.5);
        assertEquals("Lion", animal.getSpecies());
    }
}

