public class Cat extends Animal {
    private boolean isDomestic;

    public Cat(String species, int age, double weight, boolean isDomestic) {
        super(species, age, weight);
        this.isDomestic = isDomestic;
    }

    public boolean isDomestic() {
        return isDomestic;
    }

    public void setDomestic(boolean domestic) {
        isDomestic = domestic;
    }

    @Override
    public String toString() {
        return "Cat{" +
                "species='" + getSpecies() + '\'' +
                ", age=" + getAge() +
                ", weight=" + getWeight() +
                ", isDomestic=" + isDomestic +
                '}';
    }
}
