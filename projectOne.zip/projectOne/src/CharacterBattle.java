import java.util.Random;
import java.util.Scanner;

class Character {
    String name;
    int hitPoints;
    String move;
    int movePower;
    int attackSpeed;
}

public class CharacterBattle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter the number of rounds: ");
        int numRounds = scanner.nextInt();
        if (numRounds % 2 == 0) {
            System.out.println("Please enter an odd number of rounds.");
            return;
        }

        int player1Score = 0;
        int player2Score = 0;

        for (int round = 1; round <= numRounds; round++) {
            System.out.println("Round " + round + ":");

            Character player1 = createCharacter(scanner, 1);
            Character player2 = createCharacter(scanner, 2);

            int speedComparison = Integer.compare(player1.attackSpeed, player2.attackSpeed);
            int firstStriker = (speedComparison != 0) ? speedComparison : random.nextInt(2) + 1;

            while (player1.hitPoints > 0 && player2.hitPoints > 0) {
                if (firstStriker == 1) {
                    player1.hitPoints -= player2.movePower;
                    if (player1.hitPoints <= 0) {
                        System.out.println(player2.name + " is the round winner!");
                        player2Score++;
                    }
                } else {
                    player2.hitPoints -= player1.movePower;
                    if (player2.hitPoints <= 0) {
                        System.out.println(player1.name + " is the round winner!");
                        player1Score++;
                    }
                }

                firstStriker = 3 - firstStriker; // Switch between players (1 and 2)
            }
        }

        System.out.println("\nFinal Scores:");
        System.out.println("Player 1: " + player1Score + " points");
        System.out.println("Player 2: " + player2Score + " points");
    }

    private static Character createCharacter(Scanner scanner, int playerNumber) {
        Character character = new Character();
        System.out.println("\nPlayer " + playerNumber + "'s turn:");

        System.out.print("Enter character name: ");
        character.name = scanner.next();

        System.out.print("Enter HP: ");
        character.hitPoints = scanner.nextInt();

        System.out.print("Enter move: ");
        character.move = scanner.next();

        System.out.print("Enter move's power: ");
        character.movePower = scanner.nextInt();

        System.out.print("Enter attack speed: ");
        character.attackSpeed = scanner.nextInt();

        return character;
    }
}
