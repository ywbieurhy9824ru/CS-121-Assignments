import java.util.Scanner;

public class Menu {
    private Scanner scanner;
    private Bank bank;

    public Menu() {
        this.scanner = new Scanner(System.in);
        this.bank = new Bank();
    }

    public void runMenu() {
        int choice;
        do {
            displayMainMenu();
            System.out.print(">>");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    openNewAccount();
                    break;
                case 2:
                    accessAccount();
                    break;
                case 3:
                    closeAllAccounts();
                    break;
                case 4:
                    System.out.println("Thank you for using BSU Banking APP Goodbye. Exiting....");
                    break;
                default:
                    System.out.println("Invalid entry. Please enter a number between 1 and 4.");
            }
        } while (choice != 4);
    }

    private void displayMainMenu() {
        System.out.println("********MENU********");
        System.out.println("1) Open a new account");
        System.out.println("2) Access Account");
        System.out.println("3) Close all accounts");
        System.out.println("4) Exit");
    }

    private void accessAccount() {
        System.out.print("Enter your PIN: ");
        int pin = scanner.nextInt();
        Customer customer = bank.getCustomerByPIN(pin);
        if (customer == null) {
            System.out.println("PIN is not valid.");
            return;
        }
        System.out.println("****Active Accounts****"  + customer.getFirstName() + " " + customer.getLastName());
        System.out.println(customer.getAllAccountsInfo());
        System.out.print("Enter the account number you want to access: ");
        int accountNumber = scanner.nextInt();
        Account account = customer.getAccountByNumber(accountNumber);
        if (account == null) {
            System.out.println("Account number invalid.");
            return;
        }
        displayAccountMenu();
        int accountChoice = scanner.nextInt();
        switch (accountChoice) {
            case 1:
                System.out.print("Enter deposit amount: ");
                double depositAmount = scanner.nextDouble();
                account.deposit(depositAmount);
                break;
            case 2:
                System.out.print("Enter withdrawal amount: ");
                double withdrawalAmount = scanner.nextDouble();
                account.withdraw(withdrawalAmount);
                break;
            case 3:
                System.out.println("Account balance: " + account.getBalance());
                break;
            case 4:
                customer.removeAccount(account);
                System.out.println("Account closed.");
                break;
            default:
                System.out.println("Invalid entry.");
        }
    }

    private void displayAccountMenu() {
        System.out.println("******Account Menu******");
        System.out.println("1) Make a deposit");
        System.out.println("2) Make a withdrawal");
        System.out.println("3) See account balance");
        System.out.println("4) Close account");
        System.out.println("5) Exit");

    }

    private void openNewAccount() {
        System.out.print("Are you a new customer? (yes/no): ");
        String isNewCustomer = scanner.next();
        if (isNewCustomer.equalsIgnoreCase("yes")) {
            Customer newCustomer = createNewCustomer();
            if (newCustomer != null) {
                System.out.print("Please enter deposit amount: ");
                double depositAmount = scanner.nextDouble();
                Account newAccount = new Account(depositAmount);
                newCustomer.addAccount(newAccount);
                System.out.println("New Account Opened: " + newAccount.getAccountNumber());
            }
        } else if (isNewCustomer.equalsIgnoreCase("no")) {
            System.out.print("Enter your PIN: ");
            int pin = scanner.nextInt();
            Customer existingCustomer = bank.getCustomerByPIN(pin);
            if (existingCustomer == null) {
                System.out.println("PIN is not valid.");
                return;
            }
            System.out.print("Enter deposit amount for new account: ");
            double depositAmount = scanner.nextDouble();
            Account newAccount = new Account(depositAmount);
            existingCustomer.addAccount(newAccount);
            System.out.println("New Account Opened: " + newAccount.getAccountNumber());
        } else {
            System.out.println("Invalid entry.");
        }
    }

    private Customer createNewCustomer() {
        System.out.print("Enter first name: ");
        String firstName = scanner.next();
        System.out.print("Enter last name: ");
        String lastName = scanner.next();
        System.out.print("Enter 4-digit PIN: ");
        int pin = scanner.nextInt();
        Customer newCustomer = new Customer(firstName, lastName, pin);
        bank.addCustomer(newCustomer);
        return newCustomer;
    }

    private void closeAllAccounts() {
        System.out.print("Enter your PIN: ");
        int pin = scanner.nextInt();
        Customer customer = bank.getCustomerByPIN(pin);
        if (customer == null) {
            System.out.println("PIN is not valid.");
            return;
        }
        bank.removeCustomer(customer);
        System.out.println("Customer removed from bank registry.");
    }
}

