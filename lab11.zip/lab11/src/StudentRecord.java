import java.util.ArrayList;

class StudentRecord {
    private ArrayList<Student> students;

    public StudentRecord() {
        students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void removeStudent(Student student) {
        students.remove(student);
    }

    public Student getStudent(int index) {
        return students.get(index);
    }

    public ArrayList<Student> getAllStudents() {
        return students;
    }
}