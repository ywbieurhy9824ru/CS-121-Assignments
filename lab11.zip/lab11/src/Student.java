import java.util.ArrayList;

class Student {
    private String studentName;
    private int studentID;
    private ArrayList<Course> courses;

    public Student(String studentName, int studentID) {
        this.studentName = studentName;
        this.studentID = studentID;
        this.courses = new ArrayList<>();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void removeCourse(Course course) {
        courses.remove(course);
    }

    public Course getCourse(int index) {
        return courses.get(index);
    }

    public String getAllCoursesInfo() {
        StringBuilder builder = new StringBuilder();
        for (Course course : courses) {
            builder.append(course.toString()).append("\n");
        }
        return builder.toString();
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentName='" + studentName + '\'' +
                ", studentID=" + studentID +
                ", courses=" + courses +
                '}';
    }
}
