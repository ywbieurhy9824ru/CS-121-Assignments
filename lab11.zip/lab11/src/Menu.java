import java.util.Scanner;

class Menu {
    private StudentRecord studentRecord;
    private Scanner scanner;

    public Menu() {
        studentRecord = new StudentRecord();
        scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        boolean exit = false;
        while (!exit) {
            System.out.println("******Student Records******");
            System.out.println("1) Create a new student");
            System.out.println("2) Remove a student");
            System.out.println("3) Display one student's info");
            System.out.println("4) Display all students' info");
            System.out.println("5) Exit");
            System.out.print(">> ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createNewStudent();
                    break;
                case 2:
                    removeStudent();
                    break;
                case 3:
                    displayStudentInfo();
                    break;
                case 4:
                    displayAllStudentsInfo();
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    private void createNewStudent() {
        System.out.println("Enter student name: ");
        String name = scanner.nextLine();
        System.out.println("Enter student ID: ");
        int id = scanner.nextInt();
        Student student = new Student(name, id);
        // Add courses
        boolean addMoreCourses = true;
        while (addMoreCourses) {
            System.out.println("Enter course name: ");
            String courseName = scanner.next();
            System.out.println("Enter course code: ");
            int courseCode = scanner.nextInt();
            student.addCourse(new Course(courseName, courseCode));
            System.out.println("Do you want to add another course? (yes/no)");
            String choice = scanner.next();
            addMoreCourses = choice.equalsIgnoreCase("yes");
        }
        studentRecord.addStudent(student);
        System.out.println("Student added successfully!");
    }

    private void removeStudent() {
        System.out.println("Enter student ID to remove: ");
        int id = scanner.nextInt();
        Student studentToRemove = null;
        for (Student student : studentRecord.getAllStudents()) {
            if (student.getStudentID() == id) {
                studentToRemove = student;
                break;
            }
        }
        if (studentToRemove != null) {
            studentRecord.removeStudent(studentToRemove);
            System.out.println("Student removed successfully!");
        } else {
            System.out.println("Student not found with ID " + id);
        }
    }

    private void displayStudentInfo() {
        System.out.println("Enter student ID to display info: ");
        int id = scanner.nextInt();
        Student studentToDisplay = null;
        for (Student student : studentRecord.getAllStudents()) {
            if (student.getStudentID() == id) {
                studentToDisplay = student;
                break;
            }
        }
        if (studentToDisplay != null) {
            System.out.println(studentToDisplay.toString());
        } else {
            System.out.println("Student not found with ID " + id);
        }
    }

    private void displayAllStudentsInfo() {
        System.out.println("All Students Information:");
        System.out.println(studentRecord.getAllStudents());
    }
}
