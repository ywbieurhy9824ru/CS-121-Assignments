public class StringArrayListTest {
    public static void main(String[] args) {
        StringArrayList list = new StringArrayList();

        list.addString("Apple");
        list.addString("Banana");
        list.addString("Orange");
        list.addString("Grapes");

        System.out.println("Size of the ArrayList: " + list.getSize());

        System.out.println("Element at index 2: " + list.getElement(2));

        System.out.println("Displaying list using for-each loop:");
        list.displayUsingForEach();

        System.out.println("Displaying list using regular for loop:");
        list.displayUsingRegularForLoop();
    }
}

